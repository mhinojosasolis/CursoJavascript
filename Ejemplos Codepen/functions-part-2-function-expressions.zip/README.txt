A Pen created at CodePen.io. You can find this one at https://codepen.io/w3devcampus/pen/OmYmVr.

 