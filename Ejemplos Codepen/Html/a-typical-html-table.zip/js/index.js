function borderCollapse() {
  var table = document.querySelector("table");
  
  table.style.borderCollapse = "collapse";
}