window.onkeydown = function(evt) {
  document.body.innerHTML += "key = " + evt.key + "<br>";
 document.body.innerHTML += "code = " + evt.code + "<br><br>";
}