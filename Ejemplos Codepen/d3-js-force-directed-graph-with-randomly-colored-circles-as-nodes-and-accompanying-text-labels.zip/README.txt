A Pen created at CodePen.io. You can find this one at https://codepen.io/w3devcampus/pen/Bpgypq.

 A force-directed draggable graph with randomly-colored circles as nodes and accompanying text labels.