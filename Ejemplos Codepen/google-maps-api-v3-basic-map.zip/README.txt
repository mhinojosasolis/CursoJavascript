A Pen created at CodePen.io. You can find this one at https://codepen.io/w3devcampus/pen/zNQbve.

 Simple explanation of how to add a map to a website using Google Maps API v3